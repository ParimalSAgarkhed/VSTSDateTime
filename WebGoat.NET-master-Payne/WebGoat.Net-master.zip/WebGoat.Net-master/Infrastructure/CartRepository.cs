﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infrastructure
{
    public class CartRepository
    {
        public void AddToCart(int ProductId, int Quantity)
        {
            throw new NotImplementedException();
        }
    }
}
